//
//  ViewController.swift
//  TableViewProject_Nebil
//
//  Created by nebil on 4/14/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

