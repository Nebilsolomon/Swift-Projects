//
//  CellClassTableViewCell.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class CellClassTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
