//
//  ViewController.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class CountrFlag: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

