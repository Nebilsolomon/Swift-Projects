//
//  InfoOfCountries.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class InfoOfCountries: UIViewController{

   
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var labelTwo: UILabel!
    @IBOutlet weak var labelOne: UILabel!
    var myLabel1 = ""
    var myLabel2 = ""
    var newImage: UIImage?
    var number = 0;
    var Display = ""
   var newArray = CountriesFlagTableView()
    override func viewDidLoad() {
        super.viewDidLoad()
     myImage.image = newImage
     labelOne.text = myLabel1
     labelTwo.text = myLabel2
        
        
        
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "gokdemir" {
            
          let thirCV = segue.destination as? ThirdViewController
            
         
            
       
            thirCV!.newLabel =  Display
            
            
    
    }
    }
    
    
    
 
}
