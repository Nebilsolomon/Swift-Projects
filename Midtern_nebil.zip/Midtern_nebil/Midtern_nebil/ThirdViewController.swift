//
//  ThirdViewController.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var myLabelll: UILabel!
    
    var newLabel = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        myLabelll.text = newLabel
        
        // Do any additional setup after loading the view.
    }
    

    

}
