//
//  CellClass.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class CellClass: UITableViewCell {

    @IBOutlet weak var myimage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
    
}
