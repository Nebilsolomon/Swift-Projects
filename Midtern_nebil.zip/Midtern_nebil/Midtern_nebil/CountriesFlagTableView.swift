//
//  CountriesFlagTableView.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class CountriesFlagTableView: UITableViewController {
var countriesArray = [CountryFlag]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 120
        
        let jamaica = CountryFlag(name: "jamaica", image: UIImage(named: "jamaica")!, population: 40000, whereIsIt: "caribbean")
        let argentina = CountryFlag(name: "argentina", image: UIImage(named: "argentina")!,   population: 6000000, whereIsIt: "South American")
        let armenia = CountryFlag(name: "armenia", image: UIImage(named: "armenia")!, population: 70000, whereIsIt: "middle east")
        let iceland = CountryFlag(name: "iceland", image: UIImage(named: "iceland")!, population: 30000, whereIsIt: "europe")
        let iran = CountryFlag(name: "iran", image: UIImage(named: "iran")!, population: 800000, whereIsIt: "middle east")
        
        let usa = CountryFlag(name: "usa", image: UIImage(named: "usa")!, population: 400000, whereIsIt: "Norh american")
countriesArray.append(jamaica)
countriesArray.append(armenia)
countriesArray.append(argentina)
countriesArray.append(iceland)
countriesArray.append(iran)
countriesArray.append(usa)


    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return countriesArray.count
    }
  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CellClass
    
        cell?.myLabel.text = countriesArray[indexPath.row].name
       cell?.myimage.image = countriesArray[indexPath.row].image
        
    return cell!
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let xxx = tableView.indexPathForSelectedRow
        
        if segue.identifier == "nebil" {
            let destionVC = segue.destination as? InfoOfCountries
            destionVC?.myLabel1 = "\(countriesArray[(xxx?.row)!].name) population"
            destionVC?.myLabel2 = "\(countriesArray[(xxx?.row)!].population)"
            destionVC?.newImage  = countriesArray[xxx!.row].image
            destionVC!.number = (xxx?.row)!
            destionVC!.Display = countriesArray[(xxx?.row)!].toString()
            
            
            
}
    }
    
 
    



}
