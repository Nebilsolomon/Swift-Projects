//
//  CountryFlag.swift
//  Midtern_nebil
//
//  Created by nebil on 4/24/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import Foundation
import UIKit

class CountryFlag {
    var name = ""
    var image:UIImage?
    var population = 0;
    var whereIsIt = ""
    
    
    init(name:String,image: UIImage,population:Int , whereIsIt :String) {
        self.name = name
        self.image = image
        self.population = population
        self.whereIsIt = whereIsIt
    }
    
    
    func toString() -> String {
        
        return "\(name) popu is \(population)and it is in \(whereIsIt)"
        
    }
    
    
}
