//
//  ViewController.swift
//  ToDoList
//
//  Created by nebil on 6/10/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class ToDoListViewController: UITableViewController {
    var itemArray = ["nebil","gokdemir","suleyman","mehmet"]
    var saveDate = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if let item = saveDate.array(forKey: "saveToDoList") as? [String] {
            
        itemArray = item
            
        }
        
        
    }

    
    
    //MARK - TableView DataSource Method
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return itemArray.count
    }
    
  //MARK - nebilgokdemior  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TodoItemList", for: indexPath)
        cell.textLabel?.text  = itemArray[indexPath.row]
        return cell 
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print(itemArray[indexPath.row])
        
        if tableView.cellForRow(at: indexPath)?.accessoryType == .checkmark {
            tableView.cellForRow(at: indexPath)?.accessoryType = .none
        }
        else {
            tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        }
        
        
        
        tableView.deselectRow(at: indexPath, animated: true)
       
    }

    
    
    
    @IBAction func addItem(_ sender: UIBarButtonItem) {
        
        var myText = UITextField()
        
        let alert = UIAlertController(title: "Add new ToDoList", message: "", preferredStyle: .alert)
        
        let alertAction = UIAlertAction(title: "ADD", style: .default) { (action) in
        
            self.itemArray.append(myText.text!)
            self.saveDate.set(self.itemArray, forKey: "saveToDoList")
            
            
            self.tableView.reloadData()
            print(myText.text!)
            
            
        }
        alert.addTextField { (textField) in
            textField.placeholder = "Creat New Item"
            print(textField.text!)
            myText = textField
            
        }
        
        alert.addAction(alertAction)
       self.present(alert, animated: true, completion: nil)
    
    }
    
    
}

