//
//  ViewController.swift
//  ParseJson
//
//  Created by nebil on 9/3/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit
class xcountries: Decodable {
    var name: String
    var region : String
    var capital : String
}

class ViewController: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        let url = "https://restcountries.eu/rest/v2/all"
       
          let urlObj = URL(string: url2)
  
        URLSession.shared.dataTask(with: urlObj!) { (data, urlresponce, error) in
            do {
          
                let countries = try JSONDecoder().decode([xcountries].self, from: data!)
            
                for x in countries {
                    
                    print("name of country = " + x.name + "capital is = " + x.capital )
                }
            
            
            }
            catch {
                
                print(error)
            }
            
            
            
        }
        .resume()
        
    
    
    
    
    }


}

