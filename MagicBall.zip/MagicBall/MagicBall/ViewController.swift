//
//  ViewController.swift
//  MagicBall
//
//  Created by nebil on 12/7/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    let ballArray = ["ball1","ball2","ball3","ball4","ball5"]
    var ramdomnum = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
             imageView.image = UIImage(named: ballArray[1])
    }

    @IBAction func askButtonPressed(_ sender: Any) {
        
       giveRamdomImage()
        
    }
    
    

    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        giveRamdomImage()
    }
    
    func giveRamdomImage()  {
        ramdomnum = Int(arc4random_uniform(4))
        imageView.image = UIImage(named: ballArray[ramdomnum])
        
    }
}

