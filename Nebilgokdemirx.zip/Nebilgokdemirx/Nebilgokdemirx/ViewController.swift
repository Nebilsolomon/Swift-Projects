//
//  ViewController.swift
//  Nebilgokdemirx
//
//  Created by nebil on 9/23/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    var myArray = [Info]()
    
    @IBOutlet weak var myLabel: UILabel!
    
    
    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
 let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadData()
        myLabel.text = myArray[1].fullName
        
    
    
    
    }

    @IBAction func summit(_ sender: UIButton) {
   
        let myText1 = textField1.text
        let myText2 = textField2.text
        let fullNamex = myText1! + myText2!
        
        
       
        let name =   Info(context: contex!)
        name.fullName = fullNamex
        myArray.append(name)
        myLabel.text = fullNamex
        savaData()
        
    
    
    
    
    }
    
    
    
    func savaData()   {
        
        do {
            try! contex?.save()
        print("data was saved")
        }catch {
            
            
        }
        
        
        
    }
    
    func loadData()  {
        
        let request :NSFetchRequest<Info> = Info.fetchRequest()
        
        
        do {
            myArray = try (contex?.fetch(request))!
        }
        catch {
            
            
            
        }
        
        
        
        
    }
    
}

