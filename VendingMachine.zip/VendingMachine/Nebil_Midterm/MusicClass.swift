//
//  MusicClass.swift
//  Nebil_Midterm
//
//  Created by nebil on 10/29/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import Foundation
import AVFoundation

class MusicClass {
    
    var crabYourMoneyMusic = AVAudioPlayer()
    var youDontHaveEnoughMoneyMusic = AVAudioPlayer()
    var dropCoinSound = AVAudioPlayer()
    

    func musicForcrabYourMoney() {
        
        do {
            let path = Bundle.main.path(forResource: "pleaseGrabYourChange", ofType: "mp3")
            crabYourMoneyMusic = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            crabYourMoneyMusic.prepareToPlay()
        }
        catch {
            print(error)
        }
    }
  
    func musicFordropCoinSound() {
        
        do {
            let path = Bundle.main.path(forResource: "coin_drop_sound", ofType: "mp3")
            dropCoinSound = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            dropCoinSound.prepareToPlay()
        }
        catch {
            print(error)
        }
    }
    func musicForyouDontHaveEnoughMoneyMusic() {
        
        do {
            let path = Bundle.main.path(forResource: "youDonthaveenoughmoney", ofType: "mp3")
            youDontHaveEnoughMoneyMusic = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            youDontHaveEnoughMoneyMusic.prepareToPlay()
        }
        catch {
            print(error)
        }
    }
    
    
    func startMusicForDropCoinSound()  {
        dropCoinSound.play()
    }
    func stopMusicForDropCoinSound()  {
        dropCoinSound.stop()
    }
    
    func starMusicforyouDontHaveEnoughMoneyMusic()  {
        youDontHaveEnoughMoneyMusic.play()
    }
    func stopMusicForyouDontHaveEnoughMoneyMusic()  {
        youDontHaveEnoughMoneyMusic.stop()
    }
    func startMusicforcrabYourMoneyMusic()  {
        crabYourMoneyMusic.play()
    }
    func stopMusicForcrabYourMoneyMusic()  {
        crabYourMoneyMusic.stop()
    }
    
    
    
    
    
    
    
    
    
}
