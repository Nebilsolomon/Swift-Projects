//
//  Emoji.swift
//  CS53AMidtermFall2018
//
//  Created by nebil on 10/23/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import Foundation

class Emoji {
    var emoji = "🤪🈸🐭🐚🦊🔴🦊🐤🐼"
    var count = 0
    
    init() {
        
    }
    
    init(emoji:String) {
        self.emoji = emoji
    }
    
    
    func countEmoji()  {
        
        for _ in emoji {
           count = count + 1
        }
        print(count)
        
        
    }
    
    
    func reverseEmoji(em : String)-> String
    {
           let reversedWord = String(em.reversed())
          return reversedWord
     }
    
    
    
    func appendChar(em : String)
    {
        // your code should take first emoji from em and
        // append at end of it
        // Example let say em = “ABCD”
        // appendChar should return BCDA
      
        var emptyBox = [Character]()
     
        for x in em {
         emptyBox.append(x)
            
        }
        
        let firstChar =  emptyBox.removeFirst()
        emptyBox.append(firstChar)
     
        let printItAsString = String(emptyBox)
        print(printItAsString)
    }

    
    func countNumberOfEmoji(enterEmoji:Character)  {
        var count = 0
        
        for index in emoji {
            
            if index == enterEmoji {
         
                count = count + 1
            }
        }
        print(count)
    }
    
    
    
    func AddEmojiesAtEnd(myemoji:String)   {
        
        emoji.append(myemoji)
        
    }
    func remevoFirstEmoji()  {
        
       emoji.removeFirst()
       print(emoji)
        
    }
    
    
    

}
