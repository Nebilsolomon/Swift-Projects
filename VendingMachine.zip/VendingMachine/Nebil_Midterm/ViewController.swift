//
//  ViewController.swift
//  Nebil_Midterm
//
//  Created by nebil on 10/25/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//
       // NEBIL S GOKDEMIR
      // STUDENTID 1635427

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var myMuic = MusicClass()
    var myemoji = Emoji()
    var myemoji2 = Emoji(emoji: "🐹🐙🐊🐬")
    var priceItems = 0.0
    var yourMoney = 0.0
    @IBOutlet weak var priceOfItem: UILabel!
    @IBOutlet weak var totalOfYourMoney: UILabel!
    
    
    @IBAction func dolar(_ sender: UIButton) {
  
    self.yourMoney = self.yourMoney + 1.00
        let brokenNumber = round(100 * yourMoney) / 100
        self.totalOfYourMoney.text =  String(brokenNumber)
    
    }
    
    @IBAction func dime(_ sender: UIButton) {
         self.yourMoney = self.yourMoney + 0.10
        let brokenNumber = round(100 * yourMoney) / 100
        self.totalOfYourMoney.text =  String(brokenNumber)
    }
    
    @IBAction func nickles(_ sender: Any) {
     self.yourMoney = self.yourMoney + 0.05
        let brokenNumber = round(100 * yourMoney) / 100
        self.totalOfYourMoney.text =  String(brokenNumber)
    }
    @IBAction func Quarter(_ sender: Any) {
     self.yourMoney = self.yourMoney + 0.25
        let brokenNumber = round(100 * yourMoney) / 100
        self.totalOfYourMoney.text =  String(brokenNumber)
    }
    
    func myAlert(showMessage:String){
        let alertt = UIAlertController(title: "", message: showMessage, preferredStyle: .alert)
        let actionn = UIAlertAction(title: "OK", style: .default) { (action) in
            alertt.dismiss(animated: true, completion: nil)
        }
        alertt.addAction(actionn)
        self.present(alertt, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        myMuic.musicForyouDontHaveEnoughMoneyMusic()
        myMuic.musicForcrabYourMoney()
        myMuic.musicFordropCoinSound()
        
        myemoji2.countEmoji()
     
        myemoji2.remevoFirstEmoji()
        myemoji.appendChar(em: "🐹🐙🐊🐬")
        myemoji2.appendChar(em: "gokdemir🐊🐬")
        myemoji2.AddEmojiesAtEnd(myemoji: "🐙")
        myemoji2.countEmoji()
        print( myemoji2.reverseEmoji(em: "nebil") ) 
     
    }
    
    
    @IBAction func chip(_ sender: UIButton) {
    self.priceOfItem.text = " Price of chip is 1.35"
    priceItems = 1.35
        
    }
    
    
    @IBAction func water(_ sender: Any) {
     self.priceOfItem.text = " Price of water is 1.20"
     priceItems = 1.20
    }
    
    
    @IBAction func coke(_ sender: Any) {
          self.priceOfItem.text = " Price of coke is 1.75"
        priceItems = 1.75
    }
    
    

    @IBAction func purchase(_ sender: UIButton) {
        if yourMoney > priceItems {
            print(yourMoney)
            print(priceOfItem)
           let changes = yourMoney - priceItems
           let brokenNumber = round(100 * changes) / 100
         
      myMuic.startMusicForDropCoinSound()
      myMuic.startMusicforcrabYourMoneyMusic()
         
          self.myAlert(showMessage: "you have \(brokenNumber) change")
          self.priceOfItem.text = ""
          self.totalOfYourMoney.text = ""
            
            yourMoney = 0.0
            
        }
        else {
          
            let changes =   priceItems - yourMoney
            let brokenNumber = round(100 * changes) / 100
            
            myMuic.starMusicforyouDontHaveEnoughMoneyMusic()
            self.myAlert(showMessage: "Please deposit \(brokenNumber) to able to purchase")
            self.priceOfItem.text = ""
            self.totalOfYourMoney.text = ""
            
            yourMoney = 0.0
        }
        
        
        
        
        
    }
    
    
    
    
}

