//
//  ViewController.swift
//  SECOND-DICE
//
//  Created by nebil on 12/4/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let diceArray = ["dice1","dice2","dice3","dice4","dice5","dice6"]
    
    
    var firtRandomDiceIndex:Int = 0
    var seconRandomDiceIndex:Int = 0
    
    @IBOutlet weak var firstImageView:UIImageView!
    @IBOutlet weak var seconImageView:UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func rollButtonPressed(_ sender: UIButton) {
        updateDiceImage()
      
    }
    
    func updateDiceImage()  {
        
        firtRandomDiceIndex = Int(arc4random_uniform(6) )
        seconRandomDiceIndex = Int(arc4random_uniform(6))
       firstImageView.image = UIImage(named: diceArray[firtRandomDiceIndex])
        seconImageView.image = UIImage(named: diceArray[seconRandomDiceIndex])
        
    }
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        updateDiceImage()
    }
    
    
}

