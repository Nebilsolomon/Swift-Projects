//
//  mehmet.swift
//  SECOND-DICE
//
//  Created by nebil on 12/4/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit


class Mehmet: UIViewController {
    
}
