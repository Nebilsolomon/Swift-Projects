//
//  ViewController.swift
//  Calculate
//
//  Created by nebil on 12/10/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var work = true
    @IBOutlet weak var numLabel: UILabel!
    
    
    @IBOutlet weak var textfield2: UITextField!
    @IBOutlet weak var textfield1: UITextField!
    
    @IBOutlet weak var Button1: UIButton!
    @IBOutlet weak var Button2: UIButton!
    @IBOutlet weak var Button3: UIButton!
    @IBOutlet weak var Button4: UIButton!
    @IBOutlet weak var Button5: UIButton!
    @IBOutlet weak var Button6: UIButton!
    @IBOutlet weak var Button7: UIButton!
    @IBOutlet weak var Button8: UIButton!
    @IBOutlet weak var Button9: UIButton!
    @IBOutlet weak var Button10: UIButton!
    @IBOutlet weak var Button11: UIButton!
    @IBOutlet weak var Button15: UIButton!
    @IBOutlet weak var Button17: UIButton!
    @IBOutlet weak var Button16: UIButton!
    @IBOutlet weak var Button14: UIButton!
    @IBOutlet weak var Button12: UIButton!
    @IBOutlet weak var Button13: UIButton!
    @IBOutlet weak var Button19: UIButton!
    @IBOutlet weak var Button18: UIButton!
    @IBOutlet weak var Button20: UIButton!
    var myCalculate = Calculate(num2:0 , num1: 0)
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
             desigButton()
        
   
    
    
    }


    @IBAction func ButtonNum7(_ sender: UIButton) {
        if textfield1.isEditing {
        textfield1.text = textfield1.text! + String(sender.tag)
            if let x = textfield1.text {
            myCalculate.setNum1(num1: Int(x)!)
            }
        
//            if textfield2.isEditing {
//                work = false
//            }
        }
  
        else if textfield2.isEditing{
        textfield2.text = textfield2.text! + String(sender.tag)
            if let x = textfield2.text {
                myCalculate.setNum2(num2: Int(x)!)
            }
        }
    
      
    
    }
    

    @IBAction func AC(_ sender: UIButton) {
     myCalculate.setNum1(num1: 0)
     myCalculate.setNum2(num2: 0)
     textfield2.text = ""
     textfield1.text = ""
     numLabel.text = ""
        
    
    }
    

    @IBAction func negative(_ sender: UIButton) {
        if textfield1.isEditing {
          
            if var x = textfield1.text {
              
                }
            
               }
        
            
        else if textfield2.isEditing{
                        if var x = textfield2.text {
                            
              
            }
        }
        
        
        }
    
    
    
    @IBAction func remainder(_ sender: UIButton) {
        numLabel.text = String(myCalculate.GetRemainder())
        
    }
    
    @IBAction func Divide(_ sender: UIButton) {
     numLabel.text = String(myCalculate.GetDivOfNum())
    }
    
    @IBAction func Sum(_ sender: UIButton) {
   numLabel.text = String(myCalculate.getSumOfNum())

    }
    

    @IBAction func sub(_ sender: UIButton) {
        numLabel.text = String(myCalculate.getSubOfNum())
        
    }
    
  
    @IBAction func Multi(_ sender: UIButton) {
         numLabel.text = String(myCalculate.getMultiOfNum())
    }
    
  
    


    func desigButton()  {

        Button20.layer.cornerRadius = 10.0
        Button20.layer.masksToBounds = true
        
        Button20.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button20.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
          
       
         Button1.layer.cornerRadius = Button1.frame.size.width / 2
         Button1.layer.masksToBounds = true
         Button1.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        Button1.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
       
        Button2.layer.cornerRadius = Button2.frame.size.width / 2
        Button2.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        Button2.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
        
        Button3.layer.cornerRadius = Button3.frame.size.width / 2
        Button3.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        Button3.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
        
        
        Button4.layer.cornerRadius = Button4.frame.size.width / 2
        Button4.layer.masksToBounds = true
        Button4.backgroundColor = #colorLiteral(red: 1, green: 0.7556547193, blue: 0.264339009, alpha: 1)
        Button4.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button8.layer.cornerRadius = Button8.frame.size.width / 2
        Button8.layer.masksToBounds = true
        Button8.backgroundColor = #colorLiteral(red: 1, green: 0.7556547193, blue: 0.264339009, alpha: 1)
        Button8.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button16.layer.cornerRadius = Button16.frame.size.width / 2
        Button16.layer.masksToBounds = true
        Button16.backgroundColor = #colorLiteral(red: 1, green: 0.7556547193, blue: 0.264339009, alpha: 1)
        Button16.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button12.layer.cornerRadius = Button12.frame.size.width / 2
        Button12.layer.masksToBounds = true
        Button12.backgroundColor = #colorLiteral(red: 1, green: 0.7556547193, blue: 0.264339009, alpha: 1)
        Button12.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
//
//        Button18.layer.cornerRadius = Button18.frame.size.width / 2
//        Button18.layer.masksToBounds = true
//        Button18.backgroundColor = #colorLiteral(red: 1, green: 0.7556547193, blue: 0.264339009, alpha: 1)
//        Button18.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button5.layer.cornerRadius = Button5.frame.size.width / 2
        Button5.layer.masksToBounds = true
        Button5.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button5.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button6.layer.cornerRadius = Button6.frame.size.width / 2
        Button6.layer.masksToBounds = true
        Button6.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button6.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button7.layer.cornerRadius = Button7.frame.size.width / 2
        Button7.layer.masksToBounds = true
        Button7.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button7.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button9.layer.cornerRadius = Button9.frame.size.width / 2
        Button9.layer.masksToBounds = true
        Button9.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button9.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button10.layer.cornerRadius = Button10.frame.size.width / 2
        Button10.layer.masksToBounds = true
        Button10.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button10.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
        Button11.layer.cornerRadius = Button11.frame.size.width / 2
        Button11.layer.masksToBounds = true
        Button11.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button11.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
    
        Button15.layer.cornerRadius = Button15.frame.size.width / 2
        Button15.layer.masksToBounds = true
        Button15.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button15.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        
//        Button17.layer.cornerRadius = Button17.frame.size.width / 2
//        Button17.layer.masksToBounds = true
//        Button17.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
//        Button17.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
    
        Button14.layer.cornerRadius = Button14.frame.size.width / 2
        Button14.layer.masksToBounds = true
        Button14.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button14.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
    
        Button13.layer.cornerRadius = Button13.frame.size.width / 2
        Button13.layer.masksToBounds = true
        Button13.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        Button13.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
    }
    
}

