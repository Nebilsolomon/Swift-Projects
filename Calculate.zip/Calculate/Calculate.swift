//
//  Calculate.swift
//  Calculate
//
//  Created by nebil on 12/10/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import Foundation
class Calculate {

    var num1 = 0
    var num2 = 0

    init(num2:Int,num1:Int) {
        self.num1 = num1
        self.num2 = num2
    }


    func setNum1(num1:Int)  {
        self.num1 = num1
    }
    func setNum2(num2:Int)  {
        self.num2 = num2
    }
    func getNum1() -> Int {
        return self.num1
    }
    func getNum2() -> Int {
        return self.num2
    }
    func getSumOfNum() -> Int {
        return self.num2 + self.num1
    }
    func getSubOfNum() -> Int {
        return  self.num1 - self.num2
    }
    func getMultiOfNum() -> Int {
        return self.num1 * self.num2
    }
    func GetDivOfNum() -> Int {
        return self.num1 / self.num2
    }
    func GetRemainder() -> Int {
        
        return self.num1 % self.num2
    }




}




