//
//  ViewController.swift
//  EncoderAndDecoderDeleteIt
//
//  Created by nebil on 6/28/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit

class ViewTableController: UITableViewController {
    var myArray = [Item]()
    
    
    var myfilemanager = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("starbuck.plist")

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
print(myfilemanager)
        loadData()
        
        
        
    
    
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return myArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
       cell.textLabel?.text = myArray[indexPath.row].title
        
        if myArray[indexPath.row].done == true {
            cell.accessoryType = .checkmark
        }
        else {
            cell.accessoryType = .none
        }
        
        
    
        return cell
    }
    
    
    
   override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    if myArray[indexPath.row].done == true {
        
        myArray[indexPath.row].done = false
        print("it is false now ")
        
    }
    else {
        
        myArray[indexPath.row].done = true
        print("it is true now ")
    }
    saveData()
    tableView.reloadData()
        
        
        
    }
    
    
    
    
    @IBAction func addNewItem(_ sender: UIBarButtonItem) {
        
        var myTextField = UITextField()
        
    let alert = UIAlertController(title: "ADDITEM", message: "", preferredStyle: .alert)
        
    let alertAction = UIAlertAction(title: "ADD", style: .default) { (AlertAction) in
    
        let newItem = Item()
        newItem.title = myTextField.text!
        self.myArray.append(newItem)
        
        self.saveData()
        self.tableView.reloadData()
        
        }
        
        alert.addAction(alertAction)
        alert.addTextField { (textfieldd) in
        myTextField = textfieldd
            
        }
        self.present(alert, animated: true, completion: nil)
        
        
        
        
        
    }
    
    
    func saveData()  {
    
        let encode = PropertyListEncoder()
        
        
        
        do {
        let datax = try encode.encode(myArray)
            
            try! datax.write(to: myfilemanager!)
            
        }catch {
            print("error occour")
            
        }
        
        
        
    }
    
    
    func loadData()  {
        
        
        let decoder = PropertyListDecoder()
        do {
            var datax = try Data(contentsOf: myfilemanager!)
            self.myArray =  try! decoder.decode([Item].self , from: datax)
        }
        catch {
            
        }
       
        
        
        
        
        
        
        
    }

}

