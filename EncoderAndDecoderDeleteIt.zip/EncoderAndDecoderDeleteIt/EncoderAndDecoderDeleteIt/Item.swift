
//
//  Item.swift
//  EncoderAndDecoderDeleteIt
//
//  Created by nebil on 6/28/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import Foundation



class Item : Codable{
    var title = ""
    var done = false 
}
