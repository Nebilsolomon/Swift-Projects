//
//  EmojiesClass.swift
//  Project1
//
//  Created by nebil on 9/17/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import Foundation
import UIKit
/*******************
 CS53A
 Project1 (100 points)
 Please read on Swift String from apple document and try the following using Playground
 Or iOS as we discuss in class (if Playground running for ever, save your work and quit Xcode
 And start again).
 Let have String of emojies and apply the following methods.
 
 let emojies ="⚽️🏀🏈⚾️🎱🏉🏐🎾🚖⏰🍎🍎";
 
 Try to do the following:
 
 1. print all emojies
 2. count how may apples by goint thru emojies
 3. print all emojies up to 🎱
 4. print all emojies after 🎱
 5. add new emojies to the end
 6. remove the first emojie
 7. print emojies in reverse orther.
 
 Make sure you document and show output after
 each step.
 **************************************/
class Emojies {
    
var list = "⚽️🏀🏈⚾️🎱🏉🏐🎾🚖⏰🍎🍎"

    
    init() {
   
    }
    
    init(list:String) {
    self.list = list
    }
    

        func PrintAllEmojies()  {
    
                print(list)
          }
   
         func AddEmojiesAtEnd(emoji:String)   {
    
                list.append(emoji)
      
         }
    
    
    func  ReversedAllEmojies()  {
        let reversedWord = String(list.reversed())
        print(reversedWord)
        
    }
    
    
    
    func RemoveFirstEmojie()  {
        
       
   list.characters.remove(at: list.startIndex)
       //list.remove(at: list.startIndex)
     // list.removeFirst()
        
    
    
        
     }
    
    
    func CountHowManyApplesInEmojies()  {
      var count = 0
        
        for index in list.indices {
           
            if list[index] == "🍎"{
                
                count = count + 1
                
                }
                
            
       
        }
        print(count)
    }
    
    
    
        func   PrintAllEmojiesBeforeBlackBall() {
                if let index = list.index(of: "🎱") {
                let domains = list.prefix(upTo: index)
                print("All Black Ball Before This 🎱 =\(domains)")
            }}

    
        
       func PrintAllEmojiesAfterBlackBall() {
                if let index = list.index(of: "🎱") {
                    let domains = list.suffix(8)
                print("All Black Ball After This 🎱 =\(domains)")
            }}
  

   
   
    
    
    
    }
