//
//  ViewController.swift
//  Project1
//
//  Created by nebil on 9/16/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var EmojiesRef = Emojies()
    var myname = Emojies(list: "nebilgokdemir")
    var newEmojies = Emojies(list: "🐹🦐🐆🐻🐼")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
      
        EmojiesRef.countHowManyApplesInEmojies()
        newEmojies.removeFirstEmojie()
        newEmojies.reversedAllEmojies()
        myname.reversedAllEmojies()
      
        EmojiesRef.printAllEmojies()
        EmojiesRef.addEmojiesAtEnd(emoji: "🐰")
        EmojiesRef.printAllEmojies()
        EmojiesRef.printAllEmojiesAfterBlackBall()
        EmojiesRef.printAllEmojiesBeforeBlackBall()
        
    }

  


}

