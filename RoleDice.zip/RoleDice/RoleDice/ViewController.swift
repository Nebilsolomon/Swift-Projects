//
//  ViewController.swift
//  RoleDice
//
//  Created by nebil on 10/11/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.


        //NEBIL GOKDEMIR
       // STUDENT ID 1635427
import UIKit
import AVFoundation

class ViewController: UIViewController {
    let myDice = Dice()
    let myBank = Bank(amount: 1000)
    //  I creat AddFeatureToDice() function for some music
    let myAddFeatureToDice = AddFeatureToDice()
  
    @IBOutlet weak var labelForName: UILabel!
    @IBOutlet weak var money: UITextField!
    @IBOutlet weak var dice2: UITextField!
    @IBOutlet weak var dice1: UITextField!
    @IBOutlet weak var bet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
     money.text = String(myBank.getBalance())
     myAddFeatureToDice.musicForWinner()
     myAddFeatureToDice.musicForLoser()
     
     

 
    
    }
    
 
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        self.showTextfield()
        self.labelForName.text = ""
        
        
        
        
        
    }






    @IBAction func rollDice(_ sender: UIButton) {
        
      
        // Even though bank balance when get negative print print("No enough money") i redid it again because i want to give alert to user,so i use if myBank.getBalance() > 0 true statement in else i gave alert
    if myBank.getBalance() > 0 {
    myDice.throwDice()

    // 2 Those code make textfield text equel to random dice
    dice1.text = String(myDice.getDice1())
    dice2.text = String(myDice.getDice2())
    // I total 2 random dice here
    let totalOfDice = myDice.getDice2() + myDice.getDice1()
          // i used guard to check Bet textfield if it is not empty and if it is empty I give alert to fill it up
            guard let betEmptyOrNot = bet.text, !betEmptyOrNot.isEmpty else {
                self.myAlert(showMessage: "please type one bet")
                return
            }
        // In this state if total of random dice come 7 or 11 is win else is lose 
        if totalOfDice == 11 || totalOfDice == 7 {
        
            
            if let  betamoung = bet.text  {
                myBank.deposit(amt: (3 * Double(betamoung)!))
                // I already creat myAlert function in down below , so i just called and print how much win
                 self.myAlert(showMessage: "you won \(3 * Double(betamoung)!) dolar")
                //This function just change background of text green when player win I also created it in down below
                self.changeColorForwin()
                // I creat class which called AddFeatureToDice() all music came from this class and it has playMusicForWinner() function play music for winner
                 myAddFeatureToDice.playMusicForWinner()
               
               
                
            }
            
              money.text = String(myBank.getBalance())
        }
        else {
            
            
            if let  betamoung = bet.text{
                myBank.withDraw(amt: Double(betamoung)!)
                   // I already creat myAlert function in down below , so i just called and print how much lose
               self.myAlert(showMessage: "you lose\(betamoung) dolar")
                  //This function just change background of text red when player lose I also created it in down below
                self.changeColorForLose()
                    // I creat class which called AddFeatureToDice() all music came from this class and it has playMusicForLoser() function play music for loser
                myAddFeatureToDice.playMusicForLoser()
            }
       
            
          money.text = String(myBank.getBalance())
            
            
        }
        
        
    
        }
        else {
        // This aler function give alert user they dont have enoug money
            myAlert(showMessage: "you dont have enoug money")
        }
        
    }
    
    
    
    
    
    
    
    
    
    // this func just generate Alert.
    func myAlert(showMessage:String){
        let alertt = UIAlertController(title: "", message: showMessage, preferredStyle: .alert)
        let actionn = UIAlertAction(title: "OK", style: .default) { (action) in
            alertt.dismiss(animated: true, completion: nil)
            // Those 2 function is really importand because if i dont use those music not stop whoich is came from  AddFeatureToDice() class
            self.myAddFeatureToDice.stopMusicForWinner()
            self.myAddFeatureToDice.stopMusicForLoser()
        }
        alertt.addAction(actionn)
        self.present(alertt, animated: true, completion: nil)
        
    }
   
    // This Func change backgroundcolor of textfeild when player win.
    func changeColorForwin()  {
        money.backgroundColor  = UIColor.green
        dice1.backgroundColor  =   UIColor.green
        dice2.backgroundColor  =  UIColor.green
        bet.backgroundColor    =  UIColor.green
    }
        // This Func change backgroundcolor of textfeild when player lose.
    func changeColorForLose()  {
        money.backgroundColor    = UIColor.red
        dice1.backgroundColor  =   UIColor.red 
        dice2.backgroundColor =  UIColor.red
        bet.backgroundColor =    UIColor.red
    }
    

  // This func is for text alert as soon as when game started it come up as name of player
    func showTextfield()  {
        let alertcontroller = UIAlertController(title: "GUESS GAME", message: "if sum of dices is 7 or 11 you win 3 times ", preferredStyle: .alert)
        
        alertcontroller.addTextField { (textfield:UITextField) in
            
            textfield.placeholder = "WHAT IS YOUR NAME"
            
        }
        
        alertcontroller.addAction(UIAlertAction(title: "START", style: .default, handler: { (action:UIAlertAction) in
            if let nebil = alertcontroller.textFields?.first?.text {
                self.labelForName.text = ("Welcome \(nebil)")
            }
            
            
            
        }))
        self.present(alertcontroller, animated: true, completion: nil)
        
        
    }

    
}

