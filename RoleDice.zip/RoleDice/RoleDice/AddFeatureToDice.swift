//
//  AddFeatureToDice.swift
//  RoleDice
//
//  Created by nebil on 10/11/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation



class AddFeatureToDice
{
    // i created to AVAudioPlayer() because i want to make music for winner and also for loser
       var audioPlayerForWinner = AVAudioPlayer()
       var audioPlayerForLoser = AVAudioPlayer()
   
   // This func get path of mymusic for winner which i already import in my file
    func musicForWinner() {
   
        do {
            let path = Bundle.main.path(forResource: "mymusic", ofType: "mp3")
            audioPlayerForWinner = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            audioPlayerForWinner.prepareToPlay()
        }
        catch {
            print(error)
        }
    }
    
     // This func get path of mymusic for loser which i already import in my file
    func musicForLoser() {
        
        do {
            let path = Bundle.main.path(forResource: "losemusic", ofType: "mp3")
            audioPlayerForLoser = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            audioPlayerForLoser.prepareToPlay()
        }
        catch {
            print(error)
        }
    }
    // This func play music for winner
    
    func playMusicForWinner()  {
        audioPlayerForWinner.play()
    }
    //this function stop music for winner
    func stopMusicForWinner()  {
        audioPlayerForWinner.stop()
    }
     // This func play music for loser
    func playMusicForLoser()  {
        audioPlayerForLoser.play()
    }
     //this function stop music for loser
    func stopMusicForLoser()  {
        audioPlayerForLoser.stop()
    }
    
    
    

   
       
        
    }
    


    

    
    
    
    
    

    

