//
//  ViewController.swift
//  weatherApp
//
//  Created by nebil on 7/17/20.
//  Copyright © 2020 nebilgokdemir. All rights reserved.
//

import UIKit
import Alamofire
import CoreLocation
import SwiftyJSON


class ViewController: UIViewController, CLLocationManagerDelegate {

    
    @IBOutlet weak var degreeLabel: UILabel!
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
    
      let WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather"
      let APP_ID = "e72ca729af228beabd5d20e3b7749713"
    
    let locationManager = CLLocationManager()
    let weatherData = WeatherDataModel()
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    
        
        
    }

    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let currentlocation = locations[locations.count - 1]
        
        
        if currentlocation.horizontalAccuracy > 0 {
            locationManager.stopUpdatingLocation()
            locationManager.delegate = nil
        
            
         
            let latitude =  String(currentlocation.coordinate.latitude)
            let longitude =  String(currentlocation.coordinate.longitude)
            
           
              let param : [String : String] = ["lat" : latitude, "lon" : longitude, "appid" : APP_ID]
            
            self.getWeatherData(url: WEATHER_URL, params: param)
            
            
            
            
        }
        
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
        myLabel.text = "Connection Error"
    }
    
    
    
    
    
    
    
    
    func getWeatherData(url : String , params : [String :String])  {
        
        Alamofire.request(url, method: .get, parameters: params).responseJSON { (responce) in
            
            if responce.result.isSuccess {
                
                let dataJson = JSON(responce.result.value!)
          
                self.updateWeatherData(json: dataJson)
                print(dataJson)
                
                
            }
            else {
           
            }
            
            
        }
            
        
    }
    
    
    func updateWeatherData(json:JSON)  {
        
              let tempResult = json["main"]["temp"].doubleValue
        print("temp nebil gokdeir \(tempResult)")
        
        weatherData.temperature = Int(tempResult)//- 273.15)
        
        print("nebil gokdmeirrr \(tempResult)")
        
                weatherData.city = json["name"].stringValue
        
                weatherData.condition = json["weather"][0]["id"].intValue
        
                weatherData.weatherIconName = weatherData.updateWeatherIcon(condition: weatherData.condition)
        
        
           updateUIWithWeatherData()
        
        
        
        
        
        
        
        
    }
    
    
    
    func updateUIWithWeatherData() {
        
        myLabel.text = weatherData.city
        degreeLabel.text = "\(weatherData.temperature)°"
        myImage.image = UIImage(named: weatherData.weatherIconName)
        
    }
    
    
    @IBAction func Search(_ sender: UIButton) {
   
    
    }
    
}

