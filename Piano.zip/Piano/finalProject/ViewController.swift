//
//  ViewController.swift
//  finalProject
//
//  Created by nebil on 12/8/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
  
  var playMusic: AVAudioPlayer?
  let musicArray = ["note1","note2","note3","note4","note5","note6","note7"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
   
    @IBAction func notePress(_ sender: UIButton) {
       let musicArrayIndex = sender.tag - 1
       let url = Bundle.main.url(forResource: musicArray[musicArrayIndex], withExtension: "wav")
        do {
            playMusic = try AVAudioPlayer(contentsOf: url!)
            if let nebil = playMusic {
                nebil.prepareToPlay()
                nebil.play()
            }
 
      }catch let error as Error {
           print(error)
            
        }
        
       
    
    
    }
    

}

