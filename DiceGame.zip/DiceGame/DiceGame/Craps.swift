//
//  Craps.swift
//  CrapsGame
//
//  Created by dehkhoda_abbas on 2/20/19.
//  Copyright © 2019 Santa Monica College. All rights reserved.
//

import Foundation




class Craps
{
    
    var myMusic = MusicClass()
    var myPoint = 0
    var gameStatus = Status.Continue
    var d1 = 0
    var d2 = 0
    var sum = 0
    var winTime = 0;
    var loseTime = 0;

    
    enum Status
    {
    case Win, Lost, Continue
    }
  
    enum DiceNum : Int
    {
        case Two = 2
        case Three = 3
        case Seven = 7
        case Eleven = 11
        case Twelve = 12
    }
    
    func roll()->(d1: Int , d2: Int,sum: Int)
    {
         d1 = Int(arc4random_uniform(6)) + 1
         d2 = Int(arc4random_uniform(6)) + 1
        sum = d1 + d2
        return (d1 , d2 , sum)
        
    }
    func display(roll :(d1 : Int, d2: Int, sum : Int) )->String
    {
        return ("d1:\(roll.d1) d2:\(roll.d2) sum:\(roll.sum)")
    }
    func getInfo ()->String
    {
        return "Player point:\(myPoint) d1:\(d1) d2:\(d2) sum:\(sum)"
    }
   
    
    
    func play()
    {
        var rollDice =  roll()
        
        switch rollDice.sum {
        case DiceNum.Seven.rawValue  :
            gameStatus = .Win
            winTime = winTime + 1
            myMusic.musicForWinner()
            myMusic.playWinnerMusic()
          break
        case  DiceNum.Eleven.rawValue:
            gameStatus = .Win
            winTime = winTime + 1
            myMusic.musicForWinner()
            myMusic.playWinnerMusic()
        case DiceNum.Three.rawValue,DiceNum.Twelve.rawValue, DiceNum.Two.rawValue:
            gameStatus = .Lost
            loseTime = loseTime + 1
            myMusic.musicForWinner()
            myMusic.stopWinnerMusic()
            break
        default:
            gameStatus = .Lost
            loseTime = loseTime + 1
            myMusic.musicForWinner()
            myMusic.stopWinnerMusic()
            break
            
        }
    
    
    
    
    
    
    
    
    }
  func showResult()-> String
  {
        if gameStatus == Status.Win
        {
           // print("Player wins")
            return "Player Wins"
            myMusic.musicForWinner()
            myMusic.playWinnerMusic()
            
        }
        else
        {
           // print("Player Lost")
            return "Player Lost"
            myMusic.musicForWinner()
            myMusic.stopWinnerMusic()
        }
        
    
    }
    

    func countWinAndLose() -> String {
        
        return "Win \(winTime) time Lose \(loseTime) time"
    }
    
    func setWinAndLose(win:Int, lose :Int)  {
        self.loseTime = win
        self.winTime = lose
    }
    func getWinAndLose() -> String {
         return "Win \(winTime) time Lose \(loseTime) time"
    }

    
    
}

