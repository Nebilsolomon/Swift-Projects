//
//  MusicClass.swift
//  DiceGame
//
//  Created by nebil on 3/13/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import Foundation
import AVFoundation


class MusicClass {
    
    var winnerMusic = AVAudioPlayer()

    
    func musicForWinner() {
        
        do {
            let path = Bundle.main.path(forResource: "clapping", ofType: "mp3")
            winnerMusic = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            winnerMusic.prepareToPlay()
        }
        catch {
            print(error)
        }
    }
    
  

    
    func playWinnerMusic()  {
        winnerMusic.play()
    }
    func stopWinnerMusic()  {
        
       winnerMusic.stop()
        
    }
    
    
    
}
