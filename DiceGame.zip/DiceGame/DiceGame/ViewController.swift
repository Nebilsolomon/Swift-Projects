//
//  ViewController.swift
//  DiceGame
//  Createdby nebil on 3/12/19.
//  Copyright © 2019 nebilgokdemir. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    // I creat class with MusicClass so when play won music play
    var myMusic = MusicClass()
   // creat object to get all method from Craps class
    var play = Craps()

    @IBOutlet weak var winAndLoseLabel: UILabel!
    @IBOutlet weak var disPlayLabel: UILabel!
    @IBOutlet weak var firstImage: UIImageView!
    @IBOutlet weak var secondImage: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
   // As soon as view load i put some bacground image
        firstImage.image = UIImage(named: "newbackground")
        secondImage.image = UIImage(named: "newbackground")

      
    }

    
    // I override viewDidAppear because alert doesn't work in viewDidLoad
    override func viewDidAppear(_ animated: Bool) {
        // this function is just call alert when app start
        showInfo()
    }
    
    
    
    @IBAction func rollGame(_ sender: UIButton) {
   
        // from play object i call play method to genereta 2 random number
            play.play()
       
        /*
          i have images from asset with dice1 ,dice2, //
         dice3 ...dice6 so from crap class random dice d1 and d2
      generate random image "dice\(play.d1)" and "dice\(play.d2)"
        so i sign those random image to my firstImage and secondImage
         */
            firstImage.image = UIImage(named: "dice\(play.d1)")
            secondImage.image = UIImage(named: "dice\(play.d2)")
        // sign my disPlayLabel to showResult method
        
            disPlayLabel.text = play.showResult()
        // i creat one method wihc return winnder and loser time so i sign it to winAndLoseLabel laber
            winAndLoseLabel.text = "\(play.countWinAndLose())"
      
    
    }
  
    // this function make all label and image and winAndLoseLabel to defualt
    // i havent figure out music does't stop but i just keep it anyway
    @IBAction func restart(_ sender: UIButton) {
   
        play.setWinAndLose(win: 0, lose: 0)
        firstImage.image = UIImage(named: "newbackground")
        secondImage.image = UIImage(named: "newbackground")
        disPlayLabel.text = ""
        winAndLoseLabel.text = "\(play.getWinAndLose())"
        myMusic.musicForWinner()
        myMusic.stopWinnerMusic()
        
        
        
    }
    
    
    
    
    func showInfo()  {
        let title = "شروع بازی"
        let message = "زمانی که کل داس 7 یا 11 است، بازیکن برنده است. غیر از بازیکن از دست دادن، و هنگامی که بازیکن برنده، موسیقی ستاره بازی"
        let myAlert = UIAlertController(title: "سلام استاد", message: message, preferredStyle: .alert)
        let alertAction = UIAlertAction(title: title, style: .default) { (AlertACtion) in
            
        }
        present(myAlert, animated: true, completion: nil)
        myAlert.addAction(alertAction)
    }
    
}

